smma webpage open
